## 向量搜索服务

> 安装教程

    pip install vs-1.0-py3-none-any.whl

