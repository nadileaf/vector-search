from fastapi import FastAPI
from vs.lib.logs import log

app = FastAPI()
